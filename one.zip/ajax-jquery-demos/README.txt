Please remember that you neede a PHP web server for these demos to work, and
that you must access the files via the web server (not through a local drive) -
i.e. http://127.0.0.1/ and not C:\apache\www\. They include the latest stable
version of jQuery at the time of writing. For the chat room demo, you also need
access to a MySQL server and need to run the SQL queries in the sql.sql file on
a MySQL database, then configure the script for the MySQL server.